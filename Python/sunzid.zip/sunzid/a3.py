


def remove(source,size,ind):
	source.pop(ind)
	return source


source = [1,2,3,4]
source = remove(source,4,1)
print(source)
